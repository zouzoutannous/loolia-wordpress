<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 3,
  'name' => 'Pre Wedding',
  'slug' => 'pre-wedding',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 4,
  'name' => 'Inspirational',
  'slug' => 'inspirational',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 6,
  'name' => 'Pre Wedding',
  'slug' => 'pre-wedding',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 7,
  'name' => 'Wedding Ideas',
  'slug' => 'wedding-ideas',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 8,
  'name' => 'Engagement',
  'slug' => 'engagement',
  'term_group' => 0,
  'taxonomy' => 'portfolio-category',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 90,
  'post_date' => '2021-02-01 13:11:00',
  'post_date_gmt' => '2021-02-01 13:11:00',
  'post_content' => '<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Tips on how to achieve the rustic-chic wedding theme',
  'post_excerpt' => '',
  'post_name' => 'tips-on-how-to-achieve-the-rustic-chic-wedding-theme',
  'post_modified' => '2021-02-02 21:32:18',
  'post_modified_gmt' => '2021-02-02 21:32:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=90',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"m33f249\\",\\"cols\\":[{\\"element_id\\":\\"qnxy249\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-photoshoot.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 196,
  'post_date' => '2021-01-06 15:33:00',
  'post_date_gmt' => '2021-01-06 15:33:00',
  'post_content' => '<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Your guide to an intimate elopement ceremony',
  'post_excerpt' => '',
  'post_name' => 'your-guide-to-an-intimate-elopement-ceremony',
  'post_modified' => '2021-02-02 21:31:57',
  'post_modified_gmt' => '2021-02-02 21:31:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=196',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"p95d595\\",\\"cols\\":[{\\"element_id\\":\\"hnah595\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 74,
  'post_date' => '2020-12-10 13:15:45',
  'post_date_gmt' => '2020-12-10 13:15:45',
  'post_content' => '<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Booking your next destination wedding',
  'post_excerpt' => '',
  'post_name' => 'booking-your-next-destination-wedding',
  'post_modified' => '2021-01-31 05:03:01',
  'post_modified_gmt' => '2021-01-31 05:03:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=74',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"hl7p49\\",\\"cols\\":[{\\"element_id\\":\\"dxfs51\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'inspirational',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/right-man.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 96,
  'post_date' => '2020-12-10 13:14:43',
  'post_date_gmt' => '2020-12-10 13:14:43',
  'post_content' => '<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Planning a wedding amidst the COVID-19 pandemic',
  'post_excerpt' => '',
  'post_name' => 'planning-a-wedding-amidst-the-covid-19-pandemic',
  'post_modified' => '2021-01-31 05:23:18',
  'post_modified_gmt' => '2021-01-31 05:23:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=96',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"vmfr920\\",\\"cols\\":[{\\"element_id\\":\\"sci1923\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-ring.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 87,
  'post_date' => '2020-12-10 13:10:49',
  'post_date_gmt' => '2020-12-10 13:10:49',
  'post_content' => '<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum.  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Achieve your fairytale wedding at one of these dreamy venues',
  'post_excerpt' => '',
  'post_name' => 'achieve-your-fairytale-wedding-at-one-of-these-dreamy-venues',
  'post_modified' => '2021-01-31 05:12:04',
  'post_modified_gmt' => '2021-01-31 05:12:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=87',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"qhpg72\\",\\"cols\\":[{\\"element_id\\":\\"fdfo73\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'inspirational',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/perfect-bride.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 81,
  'post_date' => '2020-12-10 13:08:19',
  'post_date_gmt' => '2020-12-10 13:08:19',
  'post_content' => '<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Unique engagement shoot ideas during the summer time',
  'post_excerpt' => '',
  'post_name' => 'unique-engagement-shoot-ideas-during-the-summer-time',
  'post_modified' => '2021-01-31 05:20:38',
  'post_modified_gmt' => '2021-01-31 05:20:38',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=81',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"atup775\\",\\"cols\\":[{\\"element_id\\":\\"qz4r776\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'inspirational',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/jonathan-wedding-day.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 199,
  'post_date' => '2020-12-09 15:38:46',
  'post_date_gmt' => '2020-12-09 15:38:46',
  'post_content' => '<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'We\'re swooning over these elegant outdoor wedding photos',
  'post_excerpt' => '',
  'post_name' => 'were-swooning-over-these-elegant-outdoor-wedding-photos',
  'post_modified' => '2021-02-02 21:32:52',
  'post_modified_gmt' => '2021-02-02 21:32:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=199',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"braa469\\",\\"cols\\":[{\\"element_id\\":\\"w1im469\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'inspirational',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-photo-1.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 200,
  'post_date' => '2020-12-08 15:34:00',
  'post_date_gmt' => '2020-12-08 15:34:00',
  'post_content' => '<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Inside this dreamy and romantic pre-wedding photoshoot',
  'post_excerpt' => '',
  'post_name' => 'inside-this-dreamy-and-romantic-pre-wedding-photoshoot',
  'post_modified' => '2021-01-31 05:27:01',
  'post_modified_gmt' => '2021-01-31 05:27:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=200',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"9e2d739\\",\\"cols\\":[{\\"element_id\\":\\"ub06739\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride-in-the-wood.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 192,
  'post_date' => '2020-12-05 15:28:00',
  'post_date_gmt' => '2020-12-05 15:28:00',
  'post_content' => '<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'A close look at this classy garden wedding reception',
  'post_excerpt' => '',
  'post_name' => 'a-close-look-at-this-classy-garden-wedding-reception',
  'post_modified' => '2021-01-31 05:37:05',
  'post_modified_gmt' => '2021-01-31 05:37:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=192',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"g0m7931\\",\\"cols\\":[{\\"element_id\\":\\"ezqd932\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'inspirational',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/together-in-harmony.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 84,
  'post_date' => '2020-11-20 13:09:00',
  'post_date_gmt' => '2020-11-20 13:09:00',
  'post_content' => '<!-- wp:paragraph -->
<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Why there is a rise in popularity for First Look shots',
  'post_excerpt' => '',
  'post_name' => 'why-there-is-a-rise-in-popularity-for-first-look-shots',
  'post_modified' => '2021-02-02 21:55:29',
  'post_modified_gmt' => '2021-02-02 21:55:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=84',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"xsqf432\\",\\"cols\\":[{\\"element_id\\":\\"1pn9433\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/jose-andrea-wedding.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 78,
  'post_date' => '2020-11-10 13:16:00',
  'post_date_gmt' => '2020-11-10 13:16:00',
  'post_content' => '<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'These photos that will convince you to a seaside wedding',
  'post_excerpt' => '',
  'post_name' => 'these-photos-that-will-convince-you-to-a-seaside-wedding',
  'post_modified' => '2021-02-02 21:30:44',
  'post_modified_gmt' => '2021-02-02 21:30:44',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=78',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5tna159\\",\\"cols\\":[{\\"element_id\\":\\"rj3s160\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/10/wedding-photo-4.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 93,
  'post_date' => '2020-10-10 13:12:00',
  'post_date_gmt' => '2020-10-10 13:12:00',
  'post_content' => '<!-- wp:paragraph -->
<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
<!-- /wp:paragraph -->

<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Finding the right bridal look for you',
  'post_excerpt' => '',
  'post_name' => 'finding-the-right-bridal-look-for-you',
  'post_modified' => '2021-02-02 21:30:24',
  'post_modified_gmt' => '2021-02-02 21:30:24',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=93',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"04p4713\\",\\"cols\\":[{\\"element_id\\":\\"pgar714\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'inspirational',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/beauty-bride.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 104,
  'post_date' => '2020-12-11 12:43:28',
  'post_date_gmt' => '2020-12-11 12:43:28',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride-613x519.png" width="613" height="519" title="bride" alt="bride" srcset="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride.png 613w, https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride-600x508.png 600w" sizes="(max-width: 613px) 100vw, 613px" />
<h4>our story</h4> <h1>YOUR OFFICIAL THIRD-WHEELERS SINCE 2008</h1> <p>What started as a hobby taking photos of close friends and families at special occasions, my partner and I met at a time when I was starting to take photography seriously.  Pairing one\'s business acumen and the other\'s visual talent, we decided to shape Wedding Photography and the rest is history. For more than 12 years, we have created witnessed and be part of the most magical moments in the lives of couples.</p>

<h3>1.5 M+</h3>
<h4>APPROXIMATE wedding images captured</h4>
<h3>12+</h3>
<h4>YEAR OF CAPTURING wedding images</h4>
<h4>WORK EXPERIENCES &amp; AWARDS</h4> <h3>Industry Recognition</h3> <p>For the past 12 years, we have been so lucky to work with a team of amazing people - from our amazing clients, peers in the industry, editors, videographers and everyone else, we have seen our Wedding Photography family create amazing memories and grow into something very special.</p>
<a href="https://themify.me/" > Book an Appointment </a>
<h3>Work Experiences</h3> <p>With many years of experience under our belt, and being recognized as one of the top Wedding Photographers in the city, we always strive to work harder and continuously learn and improve in this ever changing and competitive industry. </p>
<ul> <li> <h3>2005 - 2008</h3> </li> </ul> <p>Shot my first wedding in 2005 of a family member getting married. Took my passion in photography seriously and obtained my degree in Bachelor of Fine Arts in Photography.</p> <ul> <li> <h3>2008 - 2020</h3> </li> </ul> <p>My partner and I met in 2008 and started writing out our story to start Wedding Photography. Started creating memories with couples for over 12 years.</p>
<h3>Awards &amp; Honours</h3> <p>Ou work is always based on team-effort, working together to not only create lasting friendships but produce lasting memories</p> <ul> <li><strong>2005 - 2008</strong> - Photo recognized as Award-Winning photo in NPS Canada</li> <li><strong>2008 - 2012</strong> - Featured in The Knot, The Wedding Co. and Hello!</li> <li><strong>2012 - 2020</strong> - Recognized as one of the top Wedding Photographers</li> </ul>
<h4>let’s work together</h4> <h3>Contact Us for Pricing and Availability</h3>
<a href="https://themify.me/" > Book an appointment </a>
<p>They were with us all throughout the process, ensuring that our needs are met. The photos are a keepsake for years to come - for our kids to enjoy and for us to keep looking back to. Thank you for what you do and for capturing all the beautiful moments during our special day!</p> John & Jane October 2020 
 <p>There are no words to express how lucky we are to have you be part of our special day! The photos were undeniably good, but more than that, you made us feel so comfortable and relaxed throughout the whole process when things could get stressful. You were definitely the best decision we made and we love how you captured all the moments, the in-betweens and the laughs - all so raw and so real! Will definitely recommend to all our friends and families.</p> Kurt & Kyra August 2017
<h4>recent work</h4> <h3>Featured weddings featuring real-life love stories</h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > View All </a>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-image-a-376x500.jpg" width="376" height="500" title="Online workshops" alt="Online workshops"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > Online workshops </a> </h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-image-b-376x500.jpg" width="376" height="500" title="Wedding settings" alt="Wedding settings"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > Wedding settings </a> </h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-image-c-376x500.jpg" width="376" height="500" title="Venue photo taking" alt="Venue photo taking"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > Venue photo taking </a> </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/leaf-blue-ornament-54x64.png" width="54" height="64" title="leaf-blue-ornament" alt="leaf-blue-ornament">
<h3>Gallery</h3> <p>Follow us on Instagram for more wedding inspirations</p>

[gallery ids="122,123,124,125,126"]<!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2021-02-03 02:31:07',
  'post_modified_gmt' => '2021-02-03 02:31:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?page_id=104',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"oigu845\\",\\"cols\\":[{\\"element_id\\":\\"60b0846\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"tw0a847\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"613\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/bride.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]},{\\"element_id\\":\\"d10f848\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"98oz849\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>our story<\\\\/h4>\\\\n<h1>YOUR OFFICIAL THIRD-WHEELERS SINCE 2008<\\\\/h1>\\\\n<p>What started as a hobby taking photos of close friends and families at special occasions, my partner and I met at a time when I was starting to take photography seriously.  Pairing one\\\'s business acumen and the other\\\'s visual talent, we decided to shape Wedding Photography and the rest is history. For more than 12 years, we have created witnessed and be part of the most magical moments in the lives of couples.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"3dwp326\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#c9e4de\\",\\"divider_width\\":\\"150\\",\\"divider_type\\":\\"fullwidth\\",\\"style_divider\\":\\"solid\\"}},{\\"element_id\\":\\"9gif493\\",\\"cols\\":[{\\"element_id\\":\\"nbyf495\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"vxz1252\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>1.5 M+<\\\\/h3>\\",\\"margin_top\\":0,\\"font_size_unit\\":\\"em\\",\\"font_color_type\\":\\"font_color_solid\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_bottom\\":\\"10\\",\\"h3_margin_top_unit\\":\\"px\\",\\"h3_margin_top\\":\\"0\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"1.1\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"2.6\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ee5q675\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>APPROXIMATE wedding images captured<\\\\/h4>\\",\\"margin_top\\":0,\\"font_color_type\\":\\"font_color_solid\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.2\\"}}],\\"styling\\":{\\"padding_right\\":\\"20\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"bpej205\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rb1o207\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>12+<\\\\/h3>\\",\\"margin_top\\":0,\\"font_size_unit\\":\\"em\\",\\"font_color_type\\":\\"font_color_solid\\",\\"line_height_unit\\":\\"em\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_bottom\\":\\"10\\",\\"h3_margin_top_unit\\":\\"px\\",\\"h3_margin_top\\":\\"0\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"1.1\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"2.6\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ikyz207\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>YEAR OF CAPTURING wedding images<\\\\/h4>\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.2\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"padding_right\\":\\"20\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}],\\"styling\\":{\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top\\":\\"30\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"0,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"hide_anchor\\":false}},{\\"element_id\\":\\"x03l554\\",\\"cols\\":[{\\"element_id\\":\\"8hlx556\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"so38259\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>WORK EXPERIENCES &amp; AWARDS<\\\\/h4>\\\\n<h3>Industry Recognition<\\\\/h3>\\\\n<p>For the past 12 years, we have been so lucky to work with a team of amazing people - from our amazing clients, peers in the industry, editors, videographers and everyone else, we have seen our Wedding Photography family create amazing memories and grow into something very special.<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"29ez770\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book an Appointment\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}]},{\\"element_id\\":\\"c8b342\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"esaq769\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Work Experiences<\\\\/h3>\\\\n<p>With many years of experience under our belt, and being recognized as one of the top Wedding Photographers in the city, we always strive to work harder and continuously learn and improve in this ever changing and competitive industry. <\\\\/p>\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"30\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"p6h2134\\",\\"mod_settings\\":{\\"content_text\\":\\"<ul>\\\\n<li>\\\\n<h3>2005 - 2008<\\\\/h3>\\\\n<\\\\/li>\\\\n<\\\\/ul>\\\\n<p>Shot my first wedding in 2005 of a family member getting married. Took my passion in photography seriously and obtained my degree in Bachelor of Fine Arts in Photography.<\\\\/p>\\\\n<ul>\\\\n<li>\\\\n<h3>2008 - 2020<\\\\/h3>\\\\n<\\\\/li>\\\\n<\\\\/ul>\\\\n<p>My partner and I met in 2008 and started writing out our story to start Wedding Photography. Started creating memories with couples for over 12 years.<\\\\/p>\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"mgky486\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Awards &amp; Honours<\\\\/h3>\\\\n<p>Ou work is always based on team-effort, working together to not only create lasting friendships but produce lasting memories<\\\\/p>\\\\n<ul>\\\\n<li><strong>2005 - 2008<\\\\/strong> - Photo recognized as Award-Winning photo in NPS Canada<\\\\/li>\\\\n<li><strong>2008 - 2012<\\\\/strong> - Featured in The Knot, The Wedding Co. and Hello!<\\\\/li>\\\\n<li><strong>2012 - 2020<\\\\/strong> - Recognized as one of the top Wedding Photographers<\\\\/li>\\\\n<\\\\/ul>\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"30\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"30\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]}],\\"styling\\":{\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":\\"1\\",\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"0,81.25\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-left.jpg\\"}},{\\"element_id\\":\\"uuao13\\",\\"cols\\":[{\\"element_id\\":\\"b8gs13\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ar6c14\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>let’s work together<\\\\/h4>\\\\n<h3>Contact Us for Pricing and Availability<\\\\/h3>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"a9w815\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book an appointment\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\"}},{\\"element_id\\":\\"tlkc334\\",\\"cols\\":[{\\"element_id\\":\\"k9s2334\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"u3mb336\\",\\"mod_settings\\":{\\"layout_testimonial\\":\\"image-top\\",\\"img_h_slider\\":\\"100\\",\\"img_w_slider\\":\\"100\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>They were with us all throughout the process, ensuring that our needs are met. The photos are a keepsake for years to come - for our kids to enjoy and for us to keep looking back to. Thank you for what you do and for capturing all the beautiful moments during our special day!<\\\\/p>\\",\\"person_name_testimonial\\":\\"John & Jane\\",\\"company_testimonial\\":\\"October 2020\\"},{\\"content_testimonial\\":\\"<p>There are no words to express how lucky we are to have you be part of our special day! The photos were undeniably good, but more than that, you made us feel so comfortable and relaxed throughout the whole process when things could get stressful. You were definitely the best decision we made and we love how you captured all the moments, the in-betweens and the laughs - all so raw and so real! Will definitely recommend to all our friends and families.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Kurt & Kyra\\",\\"company_testimonial\\":\\"August 2017\\"}],\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"effect_slider\\":\\"scroll\\",\\"masonry\\":\\"disable\\",\\"grid_layout_testimonial\\":\\"list-post\\",\\"type_testimonial\\":\\"slider\\",\\"background_color\\":\\"#ffffff\\",\\"max_w_unit\\":\\"px\\",\\"min_w_unit\\":\\"px\\",\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"50\\",\\"max_w\\":\\"650\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"font_weight\\":\\"bold\\",\\"text_align\\":\\"left\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.7\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-8\\"}},{\\"element_id\\":\\"qb3y337\\",\\"grid_class\\":\\"col4-1\\"}],\\"styling\\":{\\"padding_top\\":\\"0\\",\\"padding_bottom\\":\\"62\\",\\"margin-top_opp_top\\":false,\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"100,80\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-right.png\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"o28v723\\",\\"cols\\":[{\\"element_id\\":\\"legd723\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"eoeg724\\",\\"cols\\":[{\\"element_id\\":\\"xcak725\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"pe86725\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>recent work<\\\\/h4>\\\\n<h3>Featured weddings featuring real-life love stories<\\\\/h3>\\"}}]},{\\"element_id\\":\\"i5k6726\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"ofbl726\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View All\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"right\\"}}]}],\\"styling\\":{\\"padding_bottom\\":\\"30\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"uof8315\\",\\"cols\\":[{\\"element_id\\":\\"lpyq315\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"o4ee316\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Online workshops\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-image-a-376x500.jpg\\",\\"caption_on_overlay\\":\\"yes\\",\\"style_image\\":\\"image-overlay\\",\\"width_image\\":\\"376\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\"}}]},{\\"element_id\\":\\"lykq316\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"w3js316\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Wedding settings\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-image-b-376x500.jpg\\",\\"caption_on_overlay\\":\\"yes\\",\\"style_image\\":\\"image-overlay\\",\\"width_image\\":\\"376\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\"}}]},{\\"element_id\\":\\"fiel316\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1bno316\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Venue photo taking\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-image-c-376x500.jpg\\",\\"caption_on_overlay\\":\\"yes\\",\\"style_image\\":\\"image-overlay\\",\\"width_image\\":\\"376\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\"}}]}]}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"0,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"row_width\\":\\"fullwidth\\",\\"hide_anchor\\":false}},{\\"element_id\\":\\"90pg149\\",\\"cols\\":[{\\"element_id\\":\\"k5be150\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"qfnk150\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"54\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/leaf-blue-ornament.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"v8sx151\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Gallery<\\\\/h3>\\\\n<p>Follow us on Instagram for more wedding inspirations<\\\\/p>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"9z09151\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#000000\\",\\"divider_width\\":\\"50\\",\\"divider_align\\":\\"center\\",\\"divider_type\\":\\"custom\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"gallery\\",\\"element_id\\":\\"h7ax151\\",\\"mod_settings\\":{\\"auto_scroll_opt_slider\\":\\"4\\",\\"gallery_columns\\":\\"5\\",\\"visible_opt_slider\\":\\"4\\",\\"show_arrow_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_gallery\\":\\"grid\\",\\"link_image_size\\":\\"full\\",\\"link_opt\\":\\"file\\",\\"thumb_w_gallery\\":\\"224\\",\\"thumb_h_gallery\\":\\"224\\",\\"appearance_gallery\\":false,\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_nav_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"effect_slider\\":\\"scroll\\",\\"shortcode_gallery\\":\\"[gallery ids=\\\\\\"122,123,124,125,126\\\\\\"]\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"40\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":\\"1\\",\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 134,
  'post_date' => '2020-12-11 13:41:56',
  'post_date_gmt' => '2020-12-11 13:41:56',
  'post_content' => '<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Blog',
  'post_excerpt' => '',
  'post_name' => 'blog',
  'post_modified' => '2021-02-02 18:59:01',
  'post_modified_gmt' => '2021-02-02 18:59:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?page_id=134',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"s9cx896\\",\\"cols\\":[{\\"element_id\\":\\"e31e897\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"element_id\\":\\"vcb5772\\",\\"mod_settings\\":{\\"layout_post\\":\\"list-post\\",\\"post_per_page_post\\":\\"4\\",\\"display_post\\":\\"excerpt\\",\\"hide_page_nav_post\\":\\"no\\",\\"post_type_post\\":\\"post\\",\\"hide_post_meta_post\\":\\"no\\",\\"hide_post_date_post\\":\\"yes\\",\\"unlink_post_title_post\\":\\"no\\",\\"hide_post_title_post\\":\\"no\\",\\"unlink_feat_img_post\\":\\"no\\",\\"img_height_post\\":\\"500\\",\\"auto_fullwidth_post\\":false,\\"img_width_post\\":\\"1160\\",\\"hide_feat_img_post\\":\\"no\\",\\"orderby_post\\":\\"date\\",\\"order_post\\":\\"desc\\",\\"post_filter\\":\\"no\\",\\"sticky_post\\":\\"no\\",\\"category_post\\":\\"0|single\\",\\"term_type\\":\\"category\\",\\"type_query_post\\":\\"category\\"}}]}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 138,
  'post_date' => '2020-12-11 13:51:54',
  'post_date_gmt' => '2020-12-11 13:51:54',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img loading="lazy" width="565" height="467" src="https://themify.me/demo/themes/ultra-wedding2/files/2021/01/contact.jpg" title="contact" alt="contact">
<h1>Contact Us</h1> <p>Are you ready to start your journey? We would love to be part of your story and help you create lasting memories. Let\'s talk about you and your wedding day plans. Send us a message and we will get back to you as soon as possible!</p>
<img loading="lazy" width="184" height="50" src="https://themify.me/demo/themes/ultra-wedding2/files/2021/01/signature-transparent.png" title="signature-transparent" alt="signature-transparent">
<h3>Contact Info</h3>
<h4>Address </h4>
<p>Wedding Photo Studio<br />22A Avenue 3021<br />New York City, NY<br />45218</p>
<h4>Phone</h4>
<p>+1 (230) 455-4455</p>
<h4>E-mail</h4>
<p><a href="mailto:noreply@ultra-wedding-skin.com">info@ultra-wedding2.com</a></p>
<h4>Send message</h4> <h3>Drop Us a Line</h3>
<form action="https://themify.me/demo/themes/ultra-wedding2/wp-admin/admin-ajax.php" class="builder-contact" id="tb_86ho409-form" method="post" data-post-id="0" data-element-id="86ho409" data-orig-id="" > <label for="tb_86ho409-contact-name">Name *</label> <input type="text" name="contact-name" placeholder="" id="tb_86ho409-contact-name" value="" required/> <label for="tb_86ho409-contact-email">Email *</label> <input type="text" name="contact-email" placeholder="" id="tb_86ho409-contact-email" value="" required/> <label for="tb_86ho409-contact-subject">Subject *</label> <input type="text" name="contact-subject" placeholder="" id="tb_86ho409-contact-subject" value="" required/> <label for="tb_86ho409-contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="tb_86ho409-contact-message" rows="8" cols="45" required></textarea> <button type="submit"> Send Message</button> </form><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-02-03 02:31:35',
  'post_modified_gmt' => '2021-02-03 02:31:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?page_id=138',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"4l1e686\\",\\"cols\\":[{\\"element_id\\":\\"yg1r689\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"wvpp131\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2021\\\\/01\\\\/contact.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"ito6689\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2zsp90\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact Us<\\\\/h1>\\\\n<p>Are you ready to start your journey? We would love to be part of your story and help you create lasting memories. Let\\\'s talk about you and your wedding day plans. Send us a message and we will get back to you as soon as possible!<\\\\/p>\\",\\"font_weight\\":\\"bold\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"lg6z9\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2021\\\\/01\\\\/signature-transparent.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"50\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"50\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"0,86.25\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_bottom\\":\\"135\\",\\"padding_top\\":\\"115\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2021\\\\/01\\\\/contact-leaf.png\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"65\\",\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"0,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2021\\\\/01\\\\/contact-leaf.png\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"},\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\"}},{\\"element_id\\":\\"i02h211\\",\\"cols\\":[{\\"element_id\\":\\"16mj981\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"l1td982\\",\\"cols\\":[{\\"element_id\\":\\"avpf983\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"mpch983\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Contact Info<\\\\/h3>\\",\\"padding_bottom\\":14}}]}]},{\\"element_id\\":\\"ze0h984\\",\\"cols\\":[{\\"element_id\\":\\"kue3984\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"knz8984\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Address <\\\\/h4>\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":2,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}],\\"grid_width\\":21},{\\"element_id\\":\\"x002985\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"deax985\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Wedding Photo Studio<br \\\\/>22A Avenue 3021<br \\\\/>New York City, NY<br \\\\/>45218<\\\\/p>\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":2,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false}}],\\"grid_width\\":75.7999999999999971578290569595992565155029296875}]},{\\"element_id\\":\\"2yd4985\\",\\"cols\\":[{\\"element_id\\":\\"08da986\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"as6q986\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Phone<\\\\/h4>\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":2,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}],\\"grid_width\\":21},{\\"element_id\\":\\"wq8i986\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"6hf6986\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>+1 (230) 455-4455<\\\\/p>\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":2,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false}}],\\"grid_width\\":75.7999999999999971578290569595992565155029296875}]},{\\"element_id\\":\\"al19987\\",\\"cols\\":[{\\"element_id\\":\\"c5ti987\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"qotf987\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>E-mail<\\\\/h4>\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":2,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}],\\"grid_width\\":21},{\\"element_id\\":\\"sft3987\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"hnw2987\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><a href=\\\\\\"mailto:noreply@ultra-wedding-skin.com\\\\\\">info@ultra-wedding2.com<\\\\/a><\\\\/p>\\\\n\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":2,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false}}],\\"grid_width\\":75.7999999999999971578290569595992565155029296875}]}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"50\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"50\\"}},{\\"element_id\\":\\"rmib524\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"il35525\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Send message<\\\\/h4>\\\\n<h3>Drop Us a Line<\\\\/h3>\\",\\"font_color_type\\":\\"font_color_solid\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"po_left_auto\\":false,\\"po_bottom_auto\\":false,\\"po_right_auto\\":false,\\"po_top_auto\\":false,\\"po-type\\":\\"top\\",\\"po\\":\\"relative\\",\\"h4_margin_bottom_unit\\":\\"em\\",\\"h4_margin_bottom\\":\\".1\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\"}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"86ho409\\",\\"mod_settings\\":{\\"field_name_label\\":\\"Name\\",\\"field_email_label\\":\\"Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_message_label\\":\\"Message\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{ \\\\\\"fields\\\\\\": [] }\\",\\"field_order\\":\\"{}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"style1\\",\\"border_inputs_top_width\\":\\"0\\",\\"border_inputs_top_color\\":\\"#ffffff_0.00\\",\\"border_inputs-type\\":\\"all\\",\\"background_color_send\\":\\"#875941\\"}}],\\"styling\\":{\\"background_color\\":\\"#d7aa92\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"4\\",\\"padding_right\\":\\"4\\",\\"font_color\\":\\"#ffffff\\",\\"margin-top_opp_top\\":false,\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"0\\"},\\"margin-bottom_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_top\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":false,\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"-96\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"0\\"},\\"row_anchor\\":\\"message\\",\\"margin-bottom_unit\\":\\"px\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 7,
  'post_date' => '2020-12-03 13:09:55',
  'post_date_gmt' => '2020-12-03 13:09:55',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img loading="lazy" width="71" height="81" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/leaf-white.png" title="leaf-white" alt="leaf-white">
<h4>couples | weddings | elopements</h4> <h1>CAPTURING MOMENTS ONE PHOTO AT A TIME</h1>
<a href="https://themify.me/" > Read more </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride-613x519.png" width="613" height="519" title="bride" alt="bride" srcset="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride.png 613w, https://themify.me/demo/themes/ultra-wedding2/files/2020/12/bride-600x508.png 600w" sizes="(max-width: 613px) 100vw, 613px" />
<h4>YOUR LOVE STORY</h4> <h3>CAPTURED BEHIND THE CAMERA</h3> <p>Creating images, both candid and staged, with all the laughs and the in-betweens. We are here to capture the real you and the real love. Together, let us document your day and create images which you could relive for years to come. You deserve the love-filled and unforgettable wedding of your dreams and I am here to help!</p>
<a href="https://themify.me/demo/themes/ultra-wedding2/about/" > More About Me </a>
<a href="https://www.youtube.com/watch?v=gaKiJE2C8Tk&#038;ab_channel=ChelseaandNick" > <svg><use href="#tf-ti-search"></use></svg> <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-video-900x435.jpg" width="900" height="435" title="wedding-video" alt="wedding-video" srcset="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-video-900x435.jpg 900w, https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-video-600x290.jpg 600w, https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-video-768x371.jpg 768w, https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-video-1010x488.jpg 1010w, https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-video.jpg 1013w" sizes="(max-width: 900px) 100vw, 900px" /> </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/leaf-blue-ornament-54x64.png" width="54" height="64" title="leaf-blue-ornament" alt="leaf-blue-ornament">
<h4>We Tell Stories</h4> <h3>We are here to connect and document your love story the way you want it told</h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/camera-icon-75x75.png" width="75" height="75" title="Capturing Weddings" alt="We make sure we connect with the couple and ensure that the memories that speaks of your love story are preserved."> <h3> Capturing Weddings </h3> We make sure we connect with the couple and ensure that the memories that speaks of your love story are preserved.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/love-icon-75x75.png" width="75" height="75" title="Fine Retouching" alt="Our fine retouching is to ensure each photo and each moments are enhanced, not alter. No moments will be fabricated."> <h3> Fine Retouching </h3> Our fine retouching is to ensure each photo and each moments are enhanced, not alter. No moments will be fabricated.
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/image-icon-75x75.png" width="75" height="75" title="Editing Style" alt="Everything we create is a reflection of the real feelings and the raw interactions during your special day."> <h3> Editing Style </h3> Everything we create is a reflection of the real feelings and the raw interactions during your special day.
<h4>recent work</h4> <h3>Featured weddings featuring real-life love stories</h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > View All </a>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-image-a-376x500.jpg" width="376" height="500" title="Online workshops" alt="Online workshops"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > Online workshops </a> </h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-image-b-376x500.jpg" width="376" height="500" title="Wedding settings" alt="Wedding settings"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > Wedding settings </a> </h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-image-c-376x500.jpg" width="376" height="500" title="Venue photo taking" alt="Venue photo taking"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-wedding2/portfolio/" > Venue photo taking </a> </h3>
<h4>let’s work together</h4> <h3>Contact Us for Pricing and Availability</h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/contact/#message" > Book an appointment </a>
<p>They were with us all throughout the process, ensuring that our needs are met. The photos are a keepsake for years to come - for our kids to enjoy and for us to keep looking back to. Thank you for what you do and for capturing all the beautiful moments during our special day!</p> John & Jane October 2020 
 <p>There are no words to express how lucky we are to have you be part of our special day! The photos were undeniably good, but more than that, you made us feel so comfortable and relaxed throughout the whole process when things could get stressful. You were definitely the best decision we made and we love how you captured all the moments, the in-betweens and the laughs - all so raw and so real! Will definitely recommend to all our friends and families.</p> Kurt & Kyra August 2017
<h4>DON\'T MISS THIS</h4> <h3>Featured Blog Posts</h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/12/leaf-blue-ornament-54x64.png" width="54" height="64" title="leaf-blue-ornament" alt="leaf-blue-ornament">
<h3>Gallery</h3> <p>Follow us on Instagram for more wedding inspirations</p>

[gallery ids="122,123,124,125,126"]<!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-02-03 02:30:28',
  'post_modified_gmt' => '2021-02-03 02:30:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?page_id=7',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"qx4870\\",\\"cols\\":[{\\"element_id\\":\\"gk2471\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"443k98\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/leaf-white.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"w8wy652\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>couples | weddings | elopements<\\\\/h4>\\\\n<h1>CAPTURING MOMENTS ONE PHOTO AT A TIME<\\\\/h1>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"zkn3509\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Read more\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"styling\\":{\\"text_align\\":\\"center\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/hero-banner-homepage.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":\\"15\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"15\\",\\"padding_opp_top\\":\\"1\\",\\"font_color\\":\\"#ffffff\\"}},{\\"element_id\\":\\"5gtm367\\",\\"cols\\":[{\\"element_id\\":\\"l245369\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"h4e4664\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"613\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/bride.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]},{\\"element_id\\":\\"2s3v584\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"o48w916\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>YOUR LOVE STORY<\\\\/h4>\\\\n<h3>CAPTURED BEHIND THE CAMERA<\\\\/h3>\\\\n<p>Creating images, both candid and staged, with all the laughs and the in-betweens. We are here to capture the real you and the real love. Together, let us document your day and create images which you could relive for years to come. You deserve the love-filled and unforgettable wedding of your dreams and I am here to help!<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"4914642\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"More About Me\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/about\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"15\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"0,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-top.png\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"3\\",\\"hide_anchor\\":false}},{\\"element_id\\":\\"u88l276\\",\\"cols\\":[{\\"element_id\\":\\"iu40277\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"d4qu126\\",\\"mod_settings\\":{\\"image_zoom_icon\\":\\"zoom\\",\\"param_image\\":\\"lightbox\\",\\"link_image\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/watch?v=gaKiJE2C8Tk&ab_channel=ChelseaandNick\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"900\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-video.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"i_t_b_top_width\\":\\"5\\",\\"i_t_b_top_color\\":\\"#ffffff\\",\\"i_t_b-type\\":\\"all\\"}}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"background_position\\":\\"100,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-right.png\\",\\"hide_anchor\\":false,\\"padding_bottom\\":\\"7\\",\\"padding_top\\":\\"7\\",\\"background_color\\":\\"#f5f4f2\\"}},{\\"element_id\\":\\"qolg235\\",\\"cols\\":[{\\"element_id\\":\\"hgq0237\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"zhcw491\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"54\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/leaf-blue-ornament.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"d5f0800\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>We Tell Stories<\\\\/h4>\\\\n<h3>We are here to connect and document your love story the way you want it told<\\\\/h3>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"padding_bottom\\":\\"0\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":15,\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":15,\\"padding_opp_top\\":false,\\"breakpoint_tablet\\":{\\"padding_left\\":3,\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":3,\\"padding_right_unit\\":\\"%\\"}}},{\\"element_id\\":\\"60j2472\\",\\"cols\\":[{\\"element_id\\":\\"56we473\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gk8u906\\",\\"mod_settings\\":{\\"caption_image\\":\\"We make sure we connect with the couple and ensure that the memories that speaks of your love story are preserved.\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Capturing Weddings\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/camera-icon.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"75\\"}}]},{\\"element_id\\":\\"ah8y473\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"umah69\\",\\"mod_settings\\":{\\"caption_image\\":\\"Our fine retouching is to ensure each photo and each moments are enhanced, not alter. No moments will be fabricated.\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Fine Retouching\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/love-icon.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"75\\"}}]},{\\"element_id\\":\\"lbux474\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"6bee893\\",\\"mod_settings\\":{\\"caption_image\\":\\"Everything we create is a reflection of the real feelings and the raw interactions during your special day. \\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Editing Style\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/image-icon.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"75\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"55\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":\\"1\\"}},{\\"element_id\\":\\"jap1281\\",\\"cols\\":[{\\"element_id\\":\\"bcjz283\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"mqb860\\",\\"cols\\":[{\\"element_id\\":\\"9ue061\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"e0o3938\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>recent work<\\\\/h4>\\\\n<h3>Featured weddings featuring real-life love stories<\\\\/h3>\\"}}]},{\\"element_id\\":\\"qjvh61\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"x256769\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View All\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"right\\"}}]}],\\"styling\\":{\\"padding_bottom\\":\\"30\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"r0zb961\\",\\"cols\\":[{\\"element_id\\":\\"wxdp962\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"vne4962\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Online workshops\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-image-a-376x500.jpg\\",\\"caption_on_overlay\\":\\"yes\\",\\"style_image\\":\\"image-overlay\\",\\"width_image\\":\\"376\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\"}}]},{\\"element_id\\":\\"7wfv963\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"h37g963\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Wedding settings\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-image-b-376x500.jpg\\",\\"caption_on_overlay\\":\\"yes\\",\\"style_image\\":\\"image-overlay\\",\\"width_image\\":\\"376\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\"}}]},{\\"element_id\\":\\"ytuo963\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"aykc963\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Venue photo taking\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-image-c-376x500.jpg\\",\\"caption_on_overlay\\":\\"yes\\",\\"style_image\\":\\"image-overlay\\",\\"width_image\\":\\"376\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/portfolio\\\\/\\"}}]}]}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":\\"1\\",\\"background_color\\":\\"#edf5f7\\",\\"background_position\\":\\"0,75\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"row_width\\":\\"fullwidth\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2021\\\\/02\\\\/floral-bg.png\\"}},{\\"element_id\\":\\"wabf234\\",\\"cols\\":[{\\"element_id\\":\\"fhst236\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"dw97111\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>let’s work together<\\\\/h4>\\\\n<h3>Contact Us for Pricing and Availability<\\\\/h3>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"pniu280\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book an appointment\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/contact\\\\/#message\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\"}},{\\"element_id\\":\\"3l7x689\\",\\"cols\\":[{\\"element_id\\":\\"3tfm691\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"tsz6401\\",\\"mod_settings\\":{\\"layout_testimonial\\":\\"image-top\\",\\"img_h_slider\\":\\"100\\",\\"img_w_slider\\":\\"100\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>They were with us all throughout the process, ensuring that our needs are met. The photos are a keepsake for years to come - for our kids to enjoy and for us to keep looking back to. Thank you for what you do and for capturing all the beautiful moments during our special day!<\\\\/p>\\",\\"person_name_testimonial\\":\\"John & Jane\\",\\"company_testimonial\\":\\"October 2020\\"},{\\"content_testimonial\\":\\"<p>There are no words to express how lucky we are to have you be part of our special day! The photos were undeniably good, but more than that, you made us feel so comfortable and relaxed throughout the whole process when things could get stressful. You were definitely the best decision we made and we love how you captured all the moments, the in-betweens and the laughs - all so raw and so real! Will definitely recommend to all our friends and families.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Kurt & Kyra\\",\\"company_testimonial\\":\\"August 2017\\"}],\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"effect_slider\\":\\"scroll\\",\\"masonry\\":\\"disable\\",\\"grid_layout_testimonial\\":\\"list-post\\",\\"type_testimonial\\":\\"slider\\",\\"background_color\\":\\"#ffffff\\",\\"max_w_unit\\":\\"px\\",\\"min_w_unit\\":\\"px\\",\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"50\\",\\"max_w\\":\\"650\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"font_weight\\":\\"bold\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.7\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"text_align\\":\\"left\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-8\\"}},{\\"element_id\\":\\"8s6a316\\",\\"grid_class\\":\\"col4-1\\"}],\\"styling\\":{\\"padding_top\\":0,\\"padding_bottom\\":62,\\"padding_bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"100,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-right.png\\"}},{\\"element_id\\":\\"qbs8160\\",\\"cols\\":[{\\"element_id\\":\\"h2qm163\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"4fam751\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>DON\\\'T MISS THIS<\\\\/h4>\\\\n<h3>Featured Blog Posts<\\\\/h3>\\"}}]},{\\"element_id\\":\\"a7rh848\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"element_id\\":\\"l85e905\\",\\"mod_settings\\":{\\"layout_post\\":\\"grid2\\",\\"post_per_page_post\\":\\"2\\",\\"display_post\\":\\"none\\",\\"hide_page_nav_post\\":\\"yes\\",\\"post_type_post\\":\\"post\\",\\"hide_post_meta_post\\":\\"no\\",\\"hide_post_date_post\\":\\"yes\\",\\"unlink_post_title_post\\":\\"no\\",\\"hide_post_title_post\\":\\"no\\",\\"unlink_feat_img_post\\":\\"no\\",\\"img_height_post\\":\\"220\\",\\"auto_fullwidth_post\\":false,\\"img_width_post\\":\\"370\\",\\"hide_feat_img_post\\":\\"no\\",\\"orderby_post\\":\\"date\\",\\"order_post\\":\\"desc\\",\\"post_filter\\":\\"no\\",\\"sticky_post\\":\\"no\\",\\"category_post\\":\\"0|single\\",\\"term_type\\":\\"category\\",\\"type_query_post\\":\\"category\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"7d0e235\\",\\"cols\\":[{\\"element_id\\":\\"flus236\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"f8pc236\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"54\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/leaf-blue-ornament.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3iko237\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Gallery<\\\\/h3>\\\\n<p>Follow us on Instagram for more wedding inspirations<\\\\/p>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"rizh237\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#000000\\",\\"divider_width\\":\\"50\\",\\"divider_align\\":\\"center\\",\\"divider_type\\":\\"custom\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"gallery\\",\\"element_id\\":\\"hxt1237\\",\\"mod_settings\\":{\\"auto_scroll_opt_slider\\":\\"4\\",\\"gallery_columns\\":\\"5\\",\\"visible_opt_slider\\":\\"4\\",\\"show_arrow_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_gallery\\":\\"grid\\",\\"link_image_size\\":\\"full\\",\\"link_opt\\":\\"file\\",\\"thumb_w_gallery\\":\\"224\\",\\"thumb_h_gallery\\":\\"224\\",\\"appearance_gallery\\":false,\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_nav_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"effect_slider\\":\\"scroll\\",\\"shortcode_gallery\\":\\"[gallery ids=\\\\\\"122,123,124,125,126\\\\\\"]\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"40\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":\\"1\\",\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 182,
  'post_date' => '2020-12-14 15:06:27',
  'post_date_gmt' => '2020-12-14 15:06:27',
  'post_content' => '<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Portfolio',
  'post_excerpt' => '',
  'post_name' => 'portfolio',
  'post_modified' => '2021-02-01 23:10:59',
  'post_modified_gmt' => '2021-02-01 23:10:59',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?page_id=182',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    'portfolio_layout' => 'auto_tiles',
    'portfolio_display_content' => 'none',
    'hide_portfolio_date' => 'yes',
    'portfolio_hide_meta_all' => 'yes',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"lurx259\\",\\"cols\\":[{\\"element_id\\":\\"gypb260\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"portfolio\\",\\"element_id\\":\\"9vq1432\\",\\"mod_settings\\":{\\"layout_portfolio\\":\\"auto_tiles\\",\\"post_per_page_portfolio\\":\\"7\\",\\"hide_page_nav_portfolio\\":\\"no\\",\\"display_portfolio\\":\\"none\\",\\"hide_post_meta_portfolio\\":\\"no\\",\\"hide_post_date_portfolio\\":\\"yes\\",\\"unlink_post_title_portfolio\\":\\"no\\",\\"hide_post_title_portfolio\\":\\"no\\",\\"unlink_feat_img_portfolio\\":\\"no\\",\\"img_height_portfolio\\":\\"580\\",\\"auto_fullwidth_portfolio\\":\\"1\\",\\"img_width_portfolio\\":\\"580\\",\\"hide_feat_img_portfolio\\":\\"no\\",\\"orderby_portfolio\\":\\"date\\",\\"order_portfolio\\":\\"desc\\",\\"post_filter\\":\\"yes\\",\\"category_portfolio\\":\\"0|single\\",\\"term_type\\":\\"category\\"}}]}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 382,
  'post_date' => '2021-02-02 00:33:18',
  'post_date_gmt' => '2021-02-02 00:33:18',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Services</h1>
<p>We provide a range of photography services. With more than 12-year experience in the industry, we\'ve captured thousands of happy couples and smiles. Let our lens capture your beautiful moments next.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3-800x440-800x457.jpg" width="800" height="457" title="wedding-photo-3" alt="wedding-photo-3" srcset="https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3-800x440-800x457.jpg 800w, https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3-600x343.jpg 600w, https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3-768x439.jpg 768w, https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3-1024x585.jpg 1024w, https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3-561x321.jpg 561w, https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3.jpg 1400w" sizes="(max-width: 800px) 100vw, 800px" />
<h3>Wedding Package</h3>

<p><em>from $3000</em></p>
<p>Full wedding photo package that includes pre-wedding, ceremony photos, prints, canvas, digital images, and more. </p>
<a href="https://themify.me/demo/themes/ultra-wedding2/contact/#message" > Book Now </a>
<h3>Family Portrait</h3>

<p><em>from $1000</em></p>
<p>Take your family photos either at our studio or your home. Photo prints, canvas, and digital are available.</p>
<a href="https://themify.me/demo/themes/ultra-wedding2/contact/#message" > Book Now </a>
<h3>Per Hour</h3>

<p><em>from $200/hr</em></p>
<p>Book us to take your photos anyway you want. You may hire our make-up artists for additional charges.</p>
<a href="https://themify.me/demo/themes/ultra-wedding2/contact/#message" > Book Now </a>
<h2>Other Services</h2>
<i><svg><use href="#tf-ti-desktop"></use></svg></i> Image Editing
<i><svg><use href="#tf-ti-video-camera"></use></svg></i> Video Taking
<i><svg><use href="#tf-ti-spray"></use></svg></i> Make-up
<i><svg><use href="#tf-ti-ruler-pencil"></use></svg></i> Wedding Planning
<i><svg><use href="#tf-ti-camera"></use></svg></i> Equipment Rental
<i><svg><use href="#tf-ti-printer"></use></svg></i> Canvas Printing
<h4>let’s work together</h4> <h3>Contact Us for Pricing and Availability</h3>
<a href="https://themify.me/demo/themes/ultra-wedding2/contact/#message" > Book an appointment </a>
<p>They were with us all throughout the process, ensuring that our needs are met. The photos are a keepsake for years to come - for our kids to enjoy and for us to keep looking back to. Thank you for what you do and for capturing all the beautiful moments during our special day!</p> John & Jane October 2020 
 <p>There are no words to express how lucky we are to have you be part of our special day! The photos were undeniably good, but more than that, you made us feel so comfortable and relaxed throughout the whole process when things could get stressful. You were definitely the best decision we made and we love how you captured all the moments, the in-betweens and the laughs - all so raw and so real! Will definitely recommend to all our friends and families.</p> Kurt & Kyra August 2017
<h3>Book Us Now</h3>
<form action="https://themify.me/demo/themes/ultra-wedding2/wp-admin/admin-ajax.php" class="builder-contact" id="tb_kdmz303-form" method="post" data-post-id="0" data-element-id="kdmz303" data-orig-id="" > <label for="tb_kdmz303-contact-name">Name *</label> <input type="text" name="contact-name" placeholder="" id="tb_kdmz303-contact-name" value="" required/> <label for="tb_kdmz303-contact-email">Email *</label> <input type="text" name="contact-email" placeholder="" id="tb_kdmz303-contact-email" value="" required/> <label for="tb_kdmz303-contact-subject">Subject *</label> <input type="text" name="contact-subject" placeholder="" id="tb_kdmz303-contact-subject" value="" required/> <label for="tb_kdmz303-contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="tb_kdmz303-contact-message" rows="8" cols="45" required></textarea> <button type="submit"> Send Message</button> </form><!--/themify_builder_static-->',
  'post_title' => 'Services',
  'post_excerpt' => '',
  'post_name' => 'services',
  'post_modified' => '2021-02-02 21:57:11',
  'post_modified_gmt' => '2021-02-02 21:57:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?page_id=382',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"2z2l176\\",\\"cols\\":[{\\"element_id\\":\\"yryk176\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ioth177\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Services<\\\\/h1>\\",\\"font_weight\\":\\"bold\\",\\"font_color_type\\":\\"font_color_solid\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.8\\",\\"margin_opp_left\\":false,\\"margin_right\\":\\"-82\\",\\"margin_opp_top\\":false,\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rdgd614\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>We provide a range of photography services. With more than 12-year experience in the industry, we\\\'ve captured thousands of happy couples and smiles. Let our lens capture your beautiful moments next.<\\\\/p>\\",\\"font_weight\\":\\"bold\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"text_align\\":\\"right\\"}},{\\"element_id\\":\\"iirq177\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"fdyc177\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/11\\\\/wedding-photo-3-800x440.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"width_image\\":\\"800\\"}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"50\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"50\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"100,0\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_bottom\\":\\"45\\",\\"padding_top\\":\\"115\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-right.png\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"15\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"65\\",\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"1.33,88.75\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2021\\\\/01\\\\/contact-leaf.png\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"},\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"hide_anchor\\":false,\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\"}},{\\"element_id\\":\\"34zf309\\",\\"cols\\":[{\\"element_id\\":\\"3x12310\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q3qr511\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Wedding Package<\\\\/h3>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"dac4994\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#ffffff\\",\\"divider_width\\":\\"100\\",\\"divider_align\\":\\"center\\",\\"divider_type\\":\\"custom\\",\\"bottom_margin_divider\\":\\"20\\",\\"top_margin_divider\\":\\"10\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"z0wz965\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><em>from $3000<\\\\/em><\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"dvqv647\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Full wedding photo package that includes pre-wedding, ceremony photos, prints, canvas, digital images, and more. <\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"0.85\\",\\"font_color_type\\":\\"font_color_solid\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.4\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"mr3t935\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/contact\\\\/#message\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"-30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"margin_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"link_color\\":\\"#ffffff\\",\\"button_background_color\\":\\"#b02e9f\\"}}],\\"styling\\":{\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.08\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"14\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"3\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"background_color\\":\\"#e082be\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":\\"3\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"30\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\",\\"margin-top_opp_top\\":false,\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"100\\"}},{\\"element_id\\":\\"1rem449\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"tflv450\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Family Portrait<\\\\/h3>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"apeq451\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#ffffff\\",\\"divider_width\\":\\"100\\",\\"divider_align\\":\\"center\\",\\"divider_type\\":\\"custom\\",\\"bottom_margin_divider\\":\\"20\\",\\"top_margin_divider\\":\\"10\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"uqxc451\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><em>from $1000<\\\\/em><\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"exo9451\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Take your family photos either at our studio or your home. Photo prints, canvas, and digital are available.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"0.85\\",\\"font_color_type\\":\\"font_color_solid\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.4\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"ti8e926\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/contact\\\\/#message\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"-30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"margin_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"link_color\\":\\"#ffffff\\",\\"button_background_color\\":\\"#397350\\"}}],\\"styling\\":{\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.08\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"14\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"3\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"background_color\\":\\"#72cc9e\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":\\"3\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"30\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"100\\"}},{\\"element_id\\":\\"9p7s685\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"c6xf686\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Per Hour<\\\\/h3>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"divider\\",\\"element_id\\":\\"cerm686\\",\\"mod_settings\\":{\\"stroke_w_divider\\":\\"1\\",\\"color_divider\\":\\"#ffffff\\",\\"divider_width\\":\\"100\\",\\"divider_align\\":\\"center\\",\\"divider_type\\":\\"custom\\",\\"bottom_margin_divider\\":\\"20\\",\\"top_margin_divider\\":\\"10\\",\\"style_divider\\":\\"solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"yf4x686\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><em>from $200\\\\/hr<\\\\/em><\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"9xhm686\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Book us to take your photos anyway you want. You may hire our make-up artists for additional charges.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"0.85\\",\\"font_color_type\\":\\"font_color_solid\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.4\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"byuu548\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/contact\\\\/#message\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"-30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"margin_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"link_color\\":\\"#ffffff\\",\\"button_background_color\\":\\"#6148ab\\"}}],\\"styling\\":{\\"b_sh_inset\\":false,\\"b_sh_color\\":\\"#000000_0.08\\",\\"b_sh_blur_unit\\":\\"px\\",\\"b_sh_blur\\":\\"14\\",\\"b_sh_vOffset_unit\\":\\"px\\",\\"b_sh_vOffset\\":\\"3\\",\\"b_sh_hOffset_unit\\":\\"px\\",\\"b_sh_hOffset\\":\\"0\\",\\"background_color\\":\\"#9b9be0\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":\\"3\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"30\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"100\\"}}],\\"column_h\\":1,\\"styling\\":{\\"margin-top_opp_top\\":false,\\"hide_anchor\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top\\":\\"100\\",\\"padding_bottom\\":\\"20\\",\\"background_position\\":\\"0,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-top.png\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"background_position\\":\\"0,100\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-top.png\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}},{\\"element_id\\":\\"x7rg607\\",\\"cols\\":[{\\"element_id\\":\\"0ld6608\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q6ho358\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Other Services<\\\\/h2>\\"}},{\\"element_id\\":\\"nnn1564\\",\\"cols\\":[{\\"element_id\\":\\"tvoj565\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"no4t747\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-desktop\\",\\"label\\":\\"Image Editing\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_position\\":\\"center\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"em\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_color_icon\\":\\"#b2d3de\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#ffffff\\"}}]},{\\"element_id\\":\\"pd14809\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"vd9a663\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-video-camera\\",\\"label\\":\\"Video Taking\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_position\\":\\"center\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"em\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_color_icon\\":\\"#b2d3de\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#ffffff\\"}}]},{\\"element_id\\":\\"h47y809\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"em6q316\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-spray\\",\\"label\\":\\"Make-up\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_position\\":\\"center\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"em\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_color_icon\\":\\"#b2d3de\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#ffffff\\"}}]}],\\"styling\\":{\\"padding_top\\":21}},{\\"element_id\\":\\"oq7i41\\",\\"cols\\":[{\\"element_id\\":\\"hcfj42\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"gux7526\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-ruler-pencil\\",\\"label\\":\\"Wedding Planning\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_position\\":\\"center\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"em\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_color_icon\\":\\"#b2d3de\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#ffffff\\"}}]},{\\"element_id\\":\\"2eqb43\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"ulql16\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-camera\\",\\"label\\":\\"Equipment Rental\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_position\\":\\"center\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"em\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_color_icon\\":\\"#b2d3de\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#ffffff\\"}}]},{\\"element_id\\":\\"ls5243\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"f63y87\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-printer\\",\\"label\\":\\"Canvas Printing\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_position\\":\\"center\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"30\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"em\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_color_icon\\":\\"#b2d3de\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#ffffff\\"}}]}],\\"styling\\":{\\"padding_top\\":21}}]}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"text_align\\":\\"center\\",\\"hide_anchor\\":false,\\"padding_bottom\\":\\"80\\"}},{\\"element_id\\":\\"dixd177\\",\\"cols\\":[{\\"element_id\\":\\"b3o3177\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8dam177\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>let’s work together<\\\\/h4>\\\\n<h3>Contact Us for Pricing and Availability<\\\\/h3>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"labg178\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book an appointment\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/contact\\\\/#message\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"pink\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"10\\",\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/wedding-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\"}},{\\"element_id\\":\\"7d2i856\\",\\"cols\\":[{\\"element_id\\":\\"rb73857\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"mq03857\\",\\"mod_settings\\":{\\"layout_testimonial\\":\\"image-top\\",\\"img_h_slider\\":\\"100\\",\\"img_w_slider\\":\\"100\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>They were with us all throughout the process, ensuring that our needs are met. The photos are a keepsake for years to come - for our kids to enjoy and for us to keep looking back to. Thank you for what you do and for capturing all the beautiful moments during our special day!<\\\\/p>\\",\\"person_name_testimonial\\":\\"John & Jane\\",\\"company_testimonial\\":\\"October 2020\\"},{\\"content_testimonial\\":\\"<p>There are no words to express how lucky we are to have you be part of our special day! The photos were undeniably good, but more than that, you made us feel so comfortable and relaxed throughout the whole process when things could get stressful. You were definitely the best decision we made and we love how you captured all the moments, the in-betweens and the laughs - all so raw and so real! Will definitely recommend to all our friends and families.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Kurt & Kyra\\",\\"company_testimonial\\":\\"August 2017\\"}],\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"effect_slider\\":\\"scroll\\",\\"masonry\\":\\"disable\\",\\"grid_layout_testimonial\\":\\"list-post\\",\\"type_testimonial\\":\\"slider\\",\\"background_color\\":\\"#ffffff\\",\\"max_w_unit\\":\\"px\\",\\"min_w_unit\\":\\"px\\",\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"50\\",\\"max_w\\":\\"650\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"font_weight\\":\\"bold\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.7\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.1\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"text_align\\":\\"left\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-8\\"}},{\\"element_id\\":\\"5avx302\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"anhe302\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Book Us Now<\\\\/h3>\\",\\"font_color_type\\":\\"font_color_solid\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"po_left_auto\\":false,\\"po_bottom_auto\\":false,\\"po_right_auto\\":false,\\"po_top_auto\\":false,\\"po-type\\":\\"top\\",\\"po\\":\\"relative\\",\\"h4_margin_bottom_unit\\":\\"em\\",\\"h4_margin_bottom\\":\\".1\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\"}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"kdmz303\\",\\"mod_settings\\":{\\"field_name_label\\":\\"Name\\",\\"field_email_label\\":\\"Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_message_label\\":\\"Message\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{ \\\\\\"fields\\\\\\": [] }\\",\\"field_order\\":\\"{}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"style1\\",\\"border_inputs_top_width\\":\\"0\\",\\"border_inputs_top_color\\":\\"#ffffff_0.00\\",\\"border_inputs-type\\":\\"all\\",\\"background_color_send\\":\\"#875941\\"}}],\\"styling\\":{\\"background_color\\":\\"#d7aa92\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"4\\",\\"padding_right\\":\\"4\\",\\"font_color\\":\\"#ffffff\\",\\"margin-top_opp_top\\":false,\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"0\\"},\\"margin-bottom_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"50\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\"}}],\\"styling\\":{\\"padding_top\\":0,\\"padding_bottom\\":62,\\"padding_bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"background_color\\":\\"#f5f4f2\\",\\"background_position\\":\\"0,100\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-wedding2\\\\/files\\\\/2020\\\\/12\\\\/ornament-top.png\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 180,
  'post_date' => '2021-01-14 15:00:17',
  'post_date_gmt' => '2021-01-14 15:00:17',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Winter Wonderland Engagement Photoshoot with Ana & John',
  'post_excerpt' => '',
  'post_name' => 'winter-wonderland-engagement-photoshoot-with-ana-john',
  'post_modified' => '2021-02-01 23:32:03',
  'post_modified_gmt' => '2021-02-01 23:32:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=180',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"1dnx200\\",\\"cols\\":[{\\"element_id\\":\\"lo8d201\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'engagement',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/11/wedding-photo-3.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 178,
  'post_date' => '2020-12-14 14:58:49',
  'post_date_gmt' => '2020-12-14 14:58:49',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Mike & Jane\'s Intimate Elopement',
  'post_excerpt' => '',
  'post_name' => 'mike-janes-intimate-elopement',
  'post_modified' => '2021-01-30 05:21:51',
  'post_modified_gmt' => '2021-01-30 05:21:51',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=178',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"fj8x36\\",\\"cols\\":[{\\"element_id\\":\\"mmad37\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/love-is-you.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 176,
  'post_date' => '2020-12-14 14:57:41',
  'post_date_gmt' => '2020-12-14 14:57:41',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'Josh & Kate\'s Teary First Look',
  'post_excerpt' => '',
  'post_name' => 'josh-kates-teary-first-look',
  'post_modified' => '2021-01-31 04:57:52',
  'post_modified_gmt' => '2021-01-31 04:57:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=176',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"b3ps196\\",\\"cols\\":[{\\"element_id\\":\\"o2vg196\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'engagement',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/beautiful-bride.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 174,
  'post_date' => '2020-12-14 14:56:52',
  'post_date_gmt' => '2020-12-14 14:56:52',
  'post_content' => 'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Scott & Kate\'s Dreamy Outdoor Wedding',
  'post_excerpt' => '',
  'post_name' => 'scott-kates-dreamy-outdoor-wedding',
  'post_modified' => '2021-01-30 18:38:33',
  'post_modified_gmt' => '2021-01-30 18:38:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=174',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"p3ez19\\",\\"cols\\":[{\\"element_id\\":\\"6kp220\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'wedding-ideas',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-day.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 172,
  'post_date' => '2020-12-14 14:54:28',
  'post_date_gmt' => '2020-12-14 14:54:28',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Summer Engagement Session with Joe & Beth',
  'post_excerpt' => '',
  'post_name' => 'summer-engagement-session-with-joe-beth',
  'post_modified' => '2021-01-30 18:49:23',
  'post_modified_gmt' => '2021-01-30 18:49:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=172',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zmhi473\\",\\"cols\\":[{\\"element_id\\":\\"aqgq474\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'engagement',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/together-in-love.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 170,
  'post_date' => '2020-12-14 14:53:06',
  'post_date_gmt' => '2020-12-14 14:53:06',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Paul & May\'s Romantic Garden Wedding',
  'post_excerpt' => '',
  'post_name' => 'paul-mays-romantic-garden-wedding',
  'post_modified' => '2021-01-30 18:53:49',
  'post_modified_gmt' => '2021-01-30 18:53:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=170',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"qdrs216\\",\\"cols\\":[{\\"element_id\\":\\"e89a217\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/our-big-day.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 168,
  'post_date' => '2020-12-14 14:52:04',
  'post_date_gmt' => '2020-12-14 14:52:04',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'A Dreamy Summer Bridal Photoshoot',
  'post_excerpt' => '',
  'post_name' => 'a-dreamy-summer-bridal-photoshoot',
  'post_modified' => '2021-02-01 23:31:27',
  'post_modified_gmt' => '2021-02-01 23:31:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=168',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"jnwp127\\",\\"cols\\":[{\\"element_id\\":\\"48cw127\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'wedding-ideas',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-photo-5.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 166,
  'post_date' => '2020-12-14 14:51:05',
  'post_date_gmt' => '2020-12-14 14:51:05',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Engagement Session Worth Remembering with Wes & Riz',
  'post_excerpt' => '',
  'post_name' => 'engagement-session-worth-remembering-with-wes-riz',
  'post_modified' => '2021-02-01 23:30:58',
  'post_modified_gmt' => '2021-02-01 23:30:58',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=166',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"pjlm940\\",\\"cols\\":[{\\"element_id\\":\\"p1zc941\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'engagement',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-photo-6.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 164,
  'post_date' => '2020-12-14 14:49:32',
  'post_date_gmt' => '2020-12-14 14:49:32',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Ed & Charity\'s Intimate and Romantic Wedding',
  'post_excerpt' => '',
  'post_name' => 'ed-charitys-intimate-and-romantic-wedding',
  'post_modified' => '2021-01-31 04:42:21',
  'post_modified_gmt' => '2021-01-31 04:42:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=164',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"wm4u662\\",\\"cols\\":[{\\"element_id\\":\\"um15663\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/love-couple.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 161,
  'post_date' => '2020-12-14 14:36:24',
  'post_date_gmt' => '2020-12-14 14:36:24',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'All laughter and tears at Michael & Anne\'s Reception',
  'post_excerpt' => '',
  'post_name' => 'all-laughter-and-tears-at-michael-annes-reception',
  'post_modified' => '2021-01-31 04:43:43',
  'post_modified_gmt' => '2021-01-31 04:43:43',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=161',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"lf3a715\\",\\"cols\\":[{\\"element_id\\":\\"eaq8716\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'wedding-ideas',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/happy-moment.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 188,
  'post_date' => '2020-12-06 15:23:34',
  'post_date_gmt' => '2020-12-06 15:23:34',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'Caribbean Destination Wedding with Karl & Faith',
  'post_excerpt' => '',
  'post_name' => 'caribbean-destination-wedding-with-karl-faith',
  'post_modified' => '2021-02-01 23:26:02',
  'post_modified_gmt' => '2021-02-01 23:26:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=188',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7f2p314\\",\\"cols\\":[{\\"element_id\\":\\"9465315\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'pre-wedding',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/wedding-photo-1.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 184,
  'post_date' => '2020-12-01 15:17:19',
  'post_date_gmt' => '2020-12-01 15:17:19',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Ryle & Leanne\'s Dreamy Garden Wedding',
  'post_excerpt' => '',
  'post_name' => 'ryle-leannes-dreamy-garden-wedding',
  'post_modified' => '2021-01-31 04:56:12',
  'post_modified_gmt' => '2021-01-31 04:56:12',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=184',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"c8tc953\\",\\"cols\\":[{\\"element_id\\":\\"43lv953\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'wedding-ideas',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/12/new-beggining.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 186,
  'post_date' => '2020-10-12 15:23:02',
  'post_date_gmt' => '2020-10-12 15:23:02',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Romantic Destination Wedding of Jake & Rose',
  'post_excerpt' => '',
  'post_name' => 'romantic-destination-wedding-of-jake-rose',
  'post_modified' => '2021-02-01 23:24:56',
  'post_modified_gmt' => '2021-02-01 23:24:56',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?post_type=portfolio&#038;p=186',
  'menu_order' => 0,
  'post_type' => 'portfolio',
  'meta_input' => 
  array (
    'project_date' => 'May 30, 2020',
    'project_client' => 'Todd Coleman',
    'project_services' => 'The Branch House',
    'project_launch' => 'https://themify.me/',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"qwei831\\",\\"cols\\":[{\\"element_id\\":\\"wl2i831\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'portfolio-category' => 'wedding-ideas',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-wedding2/files/2020/10/wedding-photo-4.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 66,
  'post_date' => '2020-12-03 15:23:59',
  'post_date_gmt' => '2020-12-03 15:23:59',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '66',
  'post_modified' => '2021-02-02 06:03:07',
  'post_modified_gmt' => '2021-02-02 06:03:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=66',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '7',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 133,
  'post_date' => '2020-12-11 13:38:16',
  'post_date_gmt' => '2020-12-11 13:38:16',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '133',
  'post_modified' => '2021-02-02 06:03:07',
  'post_modified_gmt' => '2021-02-02 06:03:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=133',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '104',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 437,
  'post_date' => '2021-02-02 06:03:07',
  'post_date_gmt' => '2021-02-02 06:03:07',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '437',
  'post_modified' => '2021-02-02 06:03:07',
  'post_modified_gmt' => '2021-02-02 06:03:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=437',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '382',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 190,
  'post_date' => '2020-12-14 15:24:54',
  'post_date_gmt' => '2020-12-14 15:24:54',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '190',
  'post_modified' => '2021-02-02 06:03:07',
  'post_modified_gmt' => '2021-02-02 06:03:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=190',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '182',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 136,
  'post_date' => '2020-12-11 13:42:20',
  'post_date_gmt' => '2020-12-11 13:42:20',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '136',
  'post_modified' => '2021-02-02 06:03:07',
  'post_modified_gmt' => '2021-02-02 06:03:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=136',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '134',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 141,
  'post_date' => '2020-12-11 13:52:42',
  'post_date_gmt' => '2020-12-11 13:52:42',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '141',
  'post_modified' => '2021-02-02 06:03:07',
  'post_modified_gmt' => '2021-02-02 06:03:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-wedding2/?p=141',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '138',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_text" );
$widgets[1002] = array (
  'title' => 'Office Address',
  'text' => 'Wedding Photo Studio
22A Avenue 3021
New York City, NY
45218

Let us capture your beautiful moments.
<a href="https://themify.me/demo/themes/ultra-wedding2/contact/">Contact us</a> now.',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_nav_menu" );
$widgets[1003] = array (
  'title' => 'Quick Links',
  'nav_menu' => Themify_Import_Helper::get_term_id_by_slug( "main-navigation", "nav_menu" ),
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1004] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1005] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1006] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1007] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1008] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1009] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_themify-layout-parts" );
$widgets[1010] = array (
  'title' => '',
  'layout_part' => 'footer-contact',
);
update_option( "widget_themify-layout-parts", $widgets );



$sidebars_widgets = array (
  'footer-widget-1' => 
  array (
    0 => 'text-1002',
  ),
  'footer-widget-2' => 
  array (
    0 => 'nav_menu-1003',
  ),
  'sidebar-main' => 
  array (
    0 => 'search-1004',
    1 => 'recent-posts-1005',
    2 => 'recent-comments-1006',
  ),
  'sidebar-alt' => 
  array (
    0 => 'archives-1007',
    1 => 'categories-1008',
    2 => 'meta-1009',
  ),
  'footer-social-widget' => 
  array (
    0 => 'themify-layout-parts-1010',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-webfonts_list' => 'recommended',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-default_layout' => 'sidebar-none',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_post_meta_author' => 'yes',
  'setting-default_post_meta_category' => 'no',
  'setting-default_post_meta_comment' => 'yes',
  'setting-default_post_date' => 'yes',
  'setting-default_display_date_inline' => '1',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-image_post_width' => '1160',
  'setting-image_post_height' => '500',
  'setting-default_page_post_layout' => 'sidebar-none',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_post_meta_author' => 'yes',
  'setting-default_page_post_meta_comment' => 'yes',
  'setting-default_page_display_date_inline' => '1',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-image_post_single_width' => '1160',
  'setting-image_post_single_height' => '500',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid2',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_index_hide_post_date' => 'yes',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'setting-default_portfolio_single_hide_post_date' => 'yes',
  'setting-default_portfolio_single_image_post_width' => '1400',
  'setting-default_portfolio_single_image_post_height' => '600',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '680',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-menu-split',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_form' => 'on',
  'setting_search_form' => 'live_search',
  'setting-exclude_header_widgets' => 'on',
  'setting-exclude_social_widget' => 'on',
  'setting-header_widgets' => 'none',
  'setting-footer_design' => 'footer-left-col',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-2col',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-autoinfinite' => 'on',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-wedding2/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-wedding2/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-wedding2/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-wedding2/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_ficon_themify-link-5' => 'fa-facebook',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_ficon_themify-link-6' => 'fa-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_ficon_themify-link-7' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '8',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'wedding2',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
  'site-logo_image' => '{"mode":"image","id":379,"src":"https://themify.me/demo/themes/ultra-wedding2/files/2021/02/wedding-logo.png"}',
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
